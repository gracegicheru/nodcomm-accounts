/*
* Feature Discovery - Advanced UI
*/
$(function() {
	 $('.tap-target').tapTarget('open');
    $('.tap-target').tapTarget('close');
});