/*
* Modals - Advanced UI
*/
$(function() {
    $('.modal').modal();
    $('#modal3').modal('open');
    $('#modal3').modal('close');
  });